package server;

import static db.DbConnect.*;
import java.net.*; 
import java.io.*; 
import java.sql.*;



public class Server {
    
    private Socket          socket   = null; 
    private ServerSocket    server   = null; 
    private DataInputStream cl       =  null; 
    private DataOutputStream clout       =  null;
    FileInputStream in = null;
    FileOutputStream out = null;
    
    String user_name;
    String password;
    String uname;
    
    
    public Server(int port) 
    { 
        // starts server and waits for a connection 
        try
        { 
			
			
            server = new ServerSocket(port); 
            //System.out.println("Server started"); 
	    while(true)
	    {
              start_connection();
              Auth_User();
	    }	
         }catch(IOException i){ 
            System.out.println(i); 
           } 
    }
    
    
    public void start_connection()
   {
       
        try {
           // out = new FileOutputStream("table.txt", true);
            System.out.println("Waiting for a client ..."); 
  
            socket = server.accept(); 
            System.out.println("Client accepted"); 
            
            // takes input from the client socket 
            cl = new DataInputStream(new BufferedInputStream(socket.getInputStream())); 
            clout= new DataOutputStream(socket.getOutputStream());
            
           } catch (Exception i) {
            System.out.println(i); 
           }
        
   }
    
    
   public void close_connection()
   {
       
        try {
            socket.close();
            //in.close();
           } catch (Exception i) {
            System.out.println(i); 
           }
        
   }
   
    public void data_transfer()
   {
       String line = ""; 
       
        try {
            System.out.println("Waiting for IPFS Id");
	    line = cl.readUTF();
	    System.out.println(line);
            String ipAddress = socket.getRemoteSocketAddress().toString();
	    ipAddress = ipAddress.substring(0, ipAddress.indexOf(':'));
	    String peer_id = "/ip4"+ ipAddress + "/tcp/4001/ipfs/"+line;
            
            ResultSet rs=st.executeQuery("select * from user_auth where u_id='"+user_name+"' and pass='"+password+"'");
            rs.next();
            uname=rs.getString("u_name");
            db.DbConnect.addActiveClient.setString(1,user_name);
            db.DbConnect.addActiveClient.setString(2,uname);
            db.DbConnect.addActiveClient.setString(3,peer_id);
            db.DbConnect.addActiveClient.executeUpdate();
            } catch (Exception i) {
            System.out.println(i); 
           }
        
        
           try{
                        ResultSet rs=st.executeQuery("select * from active_users ");
			line="";
			while(rs.next())  
			{   
				clout.writeUTF(rs.getString("u_name")+":"+rs.getString("con_id"));
				System.out.println(line);
			}  
			clout.writeUTF("end");
           } catch (Exception i) {
            System.out.println(i); 
           }
        
   }
    
    
    public void Auth_User()
	{
            
            try {
                user_name = cl.readUTF();
                System.out.println(user_name); 
                password=cl.readUTF();
                System.out.println(password); 
                ResultSet rs=st.executeQuery("select * from user_auth where u_id='"+user_name+"' and pass='"+password+"'");
                System.out.println(rs);
                if(rs.next())
                {
                  System.out.println("Auth_Successful");
                  clout.writeUTF("Auth_Successful");
                  System.out.println("Message Sent");
                  data_transfer();
                }
                else
                {
                    System.out.println("Auth_UnSuccessful");
                    clout.writeUTF("Auth_UnSuccessful");
                }
                close_connection();
            }catch(Exception e)
            {
                System.out.println(e); 
            }
        }
  

    public static void main(String[] args) {
        // TODO code application logic here
        Server server = new Server(5000); 
    }
    
}
