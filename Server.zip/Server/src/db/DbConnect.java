package db;

import java.sql.*;
import javax.swing.JOptionPane;

public class DbConnect {
    
    public static Connection c;
    public static Statement st;
    public static PreparedStatement addActiveClient,getActiveClient;
    
    static{
             try {
                 Class.forName("oracle.jdbc.driver.OracleDriver");
                 c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ipfs_chat","924616");
                 st=c.createStatement();
                 addActiveClient=c.prepareStatement("insert into active_users (u_id,u_name,con_id) values(?,?,?)");
                 getActiveClient=c.prepareStatement("select * from active_users ");
                } catch (Exception ex) {
                 JOptionPane.showMessageDialog(null, ex);
                }
    }
    
    
}
