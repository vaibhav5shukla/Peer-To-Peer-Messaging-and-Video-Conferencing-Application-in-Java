package gui;

import java.io.*;
import java.net.*;

public class Login extends javax.swing.JFrame {
    
     private static Socket socket		 = null; 
     private static DataInputStream input = null; 
     private static DataOutputStream out	 = null; 
     static FileOutputStream fout = null;
     static String peer_id = "";
     
     static String user_name=null;
     static String pass =null;
     ChatBox c;

    
    public Login() {
        initComponents();
    }
    
     public static void connect(String address,int port)
   {
       
        try {
            String get_peer = "ipfs id";
	    peer_id=execCmd(get_peer);
	    System.out.println(peer_id); 
	    socket = new Socket(address, port); 
	    System.out.println("Connected"); 
            // takes input from terminal 
	    input = new DataInputStream(new BufferedInputStream(socket.getInputStream())); 

	    // sends output to the socket 
	    out = new DataOutputStream(socket.getOutputStream()); 
	    fout = new FileOutputStream("swarmpeers.txt", true);
           } catch (Exception i) {
            System.out.println(i); 
           }
        
   }
    
    
    public  void get_active_user_list()
   {
        String line = ""; 
		while(true) 
		{ 
			try
			{ 
				line = input.readUTF();
				//System.out.println(line);
                                if(line.contains(":"))
                                {
                                  /*String temp=line.substring(0,line.indexOf(":"));
                                  String a=c.names.getText();
                                  a=a.concat(temp+"\n");
                                  c.names.setText(a);*/
                                }
				if(line.equals("end"))
				    break;
				byte[] strToBytes = line.getBytes();
                                fout.write(strToBytes);
			        fout.write("\n".getBytes()); 
			} 
			catch(Exception i) 
			{ 
				System.out.println(i); 
			} 
		} 
   } 
    
    
    public static String execCmd(String cmd) throws java.io.IOException 
	{
                Process process = Runtime.getRuntime().exec(cmd);
 		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String line="";
		int i=0;
		while (i<2) 
		{
		    line = reader.readLine();
		    i++;
		}
		//System.out.println(line.substring(8, line.length()-2));
                reader.close();
		return line.substring(8, line.length()-2);
    }
    
    public static void close_connection()
   {
            // close the connection 
		try
		{ 
			input.close(); 
			out.close(); 
			fout.close();
			socket.close(); 
		} 
		catch(Exception i) 
		{ 
			System.out.println(i); 
		} 
           
        
   }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel1 = new java.awt.Panel();
        panel2 = new java.awt.Panel();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        label3 = new java.awt.Label();
        login = new javax.swing.JButton();
        u = new java.awt.TextField();
        p = new javax.swing.JPasswordField();
        msg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panel2.setBackground(new java.awt.Color(0, 0, 0));

        label1.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 255));
        label1.setText("Login");

        label2.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        label2.setForeground(new java.awt.Color(255, 255, 255));
        label2.setText("Password");

        label3.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N
        label3.setForeground(new java.awt.Color(255, 255, 255));
        label3.setText("User ID");

        login.setBackground(new java.awt.Color(0, 204, 51));
        login.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        login.setText("Login");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        u.setBackground(new java.awt.Color(153, 153, 0));
        u.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        u.setForeground(new java.awt.Color(0, 0, 0));
        u.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uActionPerformed(evt);
            }
        });

        p.setBackground(new java.awt.Color(153, 153, 0));
        p.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        p.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pActionPerformed(evt);
            }
        });

        msg.setBackground(new java.awt.Color(0, 0, 0));
        msg.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout panel2Layout = new javax.swing.GroupLayout(panel2);
        panel2.setLayout(panel2Layout);
        panel2Layout.setHorizontalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(label3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(u, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                    .addComponent(p))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
                        .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(129, 129, 129))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panel2Layout.createSequentialGroup()
                        .addComponent(msg, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49))))
        );
        panel2Layout.setVerticalGroup(
            panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(u, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label3, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(22, 22, 22)
                .addGroup(panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(label2, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(p))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(msg, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(126, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(panel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(81, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
        // TODO add your handling code here:
           connect("192.168.43.206",5000);
           String s1=u.getText();
           System.out.println(s1); 
           String s2=p.getText();
           System.out.println(s2); 
           user_name=s1;
           pass=s2;
          
           try{
           System.out.println("Username and Password Received"); 
                 System.out.println(user_name); 
                 System.out.println(pass); 
                // boolean b=Auth_User(user_name, pass);
                 
                  out.writeUTF(user_name);
                  out.writeUTF(pass);
                  
                 System.out.println("Auth details sent");
                 String line="";
                 System.out.println("Waiting for Auth_result");
                 line = input.readUTF();
                 System.out.println("Message Received");
                 System.out.println(line); 
                 if(line.equals("Auth_Successful"))
                 {
                   System.out.println("User Successfully Authenticated");
		   out.writeUTF(peer_id);
                   c=new ChatBox();
                   c.setVisible(true);
                   dispose();
                   
                   Thread o = new Thread(new Subscribe());
                   o.start();
                   
                   get_active_user_list();
                   
                   Thread object = new Thread(new Group_Chat());
                   object.start();
                   
                   close_connection();
                }
                 else
                 {
                     System.out.println("User Authentication Failed");
                     msg.setText("Username or Password is Incorrect...");
                     close_connection();
                 }
                }catch(Exception u) 
		{ 
			System.out.println(u); 
		} 
        
    }//GEN-LAST:event_loginActionPerformed

    private void uActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uActionPerformed
        // TODO add your handling code here:
        p.grabFocus();
    }//GEN-LAST:event_uActionPerformed

    private void pActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pActionPerformed
        // TODO add your handling code here:
        loginActionPerformed(evt);
    }//GEN-LAST:event_pActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //Client client = new Client("127.0.0.1",5000); 
        
        
        
        try
		{ 
		 Runtime.getRuntime().exec("ipfs daemon --enable-pubsub-experiment");
		}catch(Exception u) 
		{ 
			System.out.println(u); 
		} //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label3;
    private javax.swing.JButton login;
    private javax.swing.JLabel msg;
    private javax.swing.JPasswordField p;
    private java.awt.Panel panel1;
    private java.awt.Panel panel2;
    private java.awt.TextField u;
    // End of variables declaration//GEN-END:variables
}
