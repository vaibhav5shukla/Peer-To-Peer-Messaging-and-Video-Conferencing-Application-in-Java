package gui;

import java.io.BufferedReader;
import java.io.FileReader;

public class Personal_Chat implements Runnable {
    String temp=null;
    @Override
    public void run() 
    { 
        while(true)
        {
        try
        { 
            FileReader readfile = new FileReader("PersonalChat.txt");
            BufferedReader readbuffer = new BufferedReader(readfile);
            String line="";
	    line = readbuffer.readLine();
            line=line.substring(0,line.length()-1);
            int i=line.lastIndexOf(">");
            
            if(i!=-1)
            {
             String t=line.substring(i+1,line.length());
             t=t.replaceAll("`"," ");
             if(!t.equals(temp))
            {
             System.out.println(t);
             String x=t.substring(0,t.indexOf(":"));
               if(x.equals("File"))
               {
                System.out.println("File Received");
                String hash=t.substring(t.indexOf(":")+1,t.indexOf("$"));
                String name=t.substring(t.indexOf("$")+1);
                System.out.println(hash);
                System.out.println(name);
                String cmd="ipfs get "+hash;
                Runtime.getRuntime().exec(cmd);
                System.out.println("File Saved");
                
               }
               else
              {
                ChatBox.p_chat.append(t);
                ChatBox.p_chat.append("\n");
              }
               temp=t;
            }
           }
        } 
        catch (Exception e) 
        { 
            System.out.println(e); 
        } 
        }
    } 
}

class IpSubscribe implements Runnable {
    
    int c=0;
    @Override
    public void run() 
    { 
        try
        { 
            //For Windows
                   String cmd="cmd.exe ," + "/c,"+ "Start,"+ "IpSub.vbs";
                   Runtime.getRuntime().exec(cmd);
  
        } 
        catch (Exception e) 
        { 
            System.out.println(e); 
        } 
        try
        { 
           //For Linux
                   String cmd[]={"sh","sub.sh"};
                   Runtime.getRuntime().exec(cmd);
  
        } 
        catch (Exception e) 
        { 
            System.out.println(e); 
        } 
    } 
    
}